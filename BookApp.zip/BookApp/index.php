<!DOCTYPE html>
<html>
<head>
    <title>Book List</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #008CBA;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .button {
            background-color: #008CBA;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Book List</h1>
    <form method="get">
        <label for="search">Search:</label>
        <input type="text" name="search">
        <button type="submit" class="button">Search</button>
        <button onclick="window.location.href='add-book.php'" class="button">Add Book</button>
    </form>
    <br>
    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Publisher</th>
            <th>Published Date</th>
            <th>Action</th>
        </tr>
        <?php
            // Database connection
            $conn = mysqli_connect("localhost", "root", "", "bookdb");

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Prepare a select statement
            $sql = "SELECT * FROM books";

            // Check if search query is set
            if (isset($_GET['search'])) {
                $search_term = "%" . $_GET['search'] . "%";
                $sql .= " WHERE title LIKE ?";
            }

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            if (isset($_GET['search'])) {
                mysqli_stmt_bind_param($stmt, "s", $search_term);
            }

            // Execute the prepared statement
            mysqli_stmt_execute($stmt);

            // Get result
            $result = mysqli_stmt_get_result($stmt);

            // Check if there are any books
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['title'] . "</td>";
                    echo "<td>" . $row['author'] . "</td>";
                    echo "<td>" . $row['publisher'] . "</td>";
                    echo "<td>" . $row['published_date'] . "</td>";
                    echo "<td>";
                    echo "<button onclick=\"window.location.href='edit-book.php?id=" . $row['id'] . "'\" class=\"button\">Edit</button>";
                    echo "<button onclick=\"if (confirm('Are you sure you want to delete this book?')) window.location.href='delete-book.php?id=" . $row['id'] . "'\" class=\"button\">Delete</button>";
                    echo "</td>";
                    echo "</tr>";
                   
}
} else {
echo "<tr><td colspan='6'>No books found</td></tr>";

}
// Close connection
        mysqli_close($conn);
    ?>
</table>
</body>
</html>

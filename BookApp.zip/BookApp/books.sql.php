
CREATE TABLE books (
  id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  publisher VARCHAR(255) NOT NULL,
  published_date DATE NOT NULL,
  PRIMARY KEY (id)
);



INSERT INTO books (title, author, publisher, published_date) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 'Charles Scribner\'s Sons', '1925-04-10'),
('To Kill a Mockingbird', 'Harper Lee', 'J. B. Lippincott & Co.', '1960-07-11'),
('1984', 'George Orwell', 'Secker and Warburg', '1949-06-08'),
('Pride and Prejudice', 'Jane Austen', 'T. Egerton, Whitehall', '1813-01-28'),
('The Catcher in the Rye', 'J. D. Salinger', 'Little, Brown and Company', '1951-07-16');
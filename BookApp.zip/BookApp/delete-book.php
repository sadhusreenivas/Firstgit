<?php
    // Database connection
    $conn = mysqli_connect("localhost", "username", "password", "database");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if ID is set
    if (isset($_GET['id']))
<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>
</head>
<body>
    <?php
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "bookdb");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Check if form is submitted
        if (isset($_POST['submit'])) {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $publisher = $_POST['publisher'];
            $published_date = $_POST['published_date'];

            // Prepare an insert statement
            $sql = "INSERT INTO books (title, author, publisher, published_date) VALUES (?, ?, ?, ?)";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $title, $author, $publisher, $published_date);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "Book added successfully.";
            } else {
                echo "Error adding book: " . mysqli_error($conn);
            }
        }
    ?>
    <h1>Add Book</h1>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" name="title"><br>
        <label for="author">Author:</label>
        <input type="text" name="author"><br>
        <label for="publisher">Publisher:</label>
        <input type="text" name="publisher"><br>
        <label for="published_date">Published Date:</label>
        <input type="date" name="published_date"><br>
        <button type="submit" name="submit">Add Book</button>
    </form>
</body>
</html>
N
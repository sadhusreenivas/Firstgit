<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
</head>
<body>
    <?php
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "bookdb");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli"_connect_error());
        }

        // Check if ID is set
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Prepare a select statement
            $sql = "SELECT * FROM books WHERE id = ?";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $id);

            // Execute the prepared statement
            mysqli_stmt_execute($stmt);

            // Get result
            $result = mysqli_stmt_get_result($stmt);

            // Check if book exists
            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                $title = $row['title'];
                $author = $row['author'];
                $publisher = $row['publisher'];
                $published_date = $row['published_date'];
            } else {
                echo "Book not found.";
                exit();
            }
        } else {
            echo "ID not specified.";
            exit();
        }

        // Check if form is submitted
        if (isset($_POST['submit'])) {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $publisher = $_POST['publisher'];
            $published_date = $_POST['published_date'];

            // Prepare an update statement
            $sql = "UPDATE books SET title = ?, author = ?, publisher = ?, published_date = ? WHERE id = ?";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $title, $author, $publisher, $published_date, $id);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "Book updated successfully.";
            } else {
                echo "Error updating book: " . mysqli_error($conn);
            }
        }
    ?>
    <h1>Edit Book</h1>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" value="<?php echo $title; ?>"><br>
        <label for="author">Author:</label>
        <input type="text" name="author" value="<?php echo $author; ?>"><br>
        <label for="publisher">Publisher:</label>
        <input type="text" name="publisher" value="<?php echo $publisher; ?>"><br>
        <label for="published_date">Published Date:</label>
        <input type="date" name="published_date" value="<?php echo $published_date; ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
</body>
</html>
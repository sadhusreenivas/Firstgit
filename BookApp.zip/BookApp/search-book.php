<!DOCTYPE html>
<html>
<head>
    <title>Search Book</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #008CBA;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .button {
            background-color: #008CBA;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Search Book</h1>
    <form method="get" action="search-book.php">
        <label for="search">Search:</label>
        <input type="text" name="search">
        <button type="submit" class="button">Search</button>
    </form>
    <br>
    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Publisher</th>
            <th>Published Date</th>
        </tr>
        <?php
            // Database connection
            $conn = mysqli_connect(""localhost", "root", "", "bookdb");

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Check if search query is set
            if (isset($_GET['search'])) {
                $search_term = "%" . $_GET['search'] . "%";

                // Prepare a select statement
                $sql = "SELECT * FROM books WHERE title LIKE ?";
                $stmt = mysqli_prepare($conn, $sql);

                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "s", $search_term);

                // Execute the prepared statement
                mysqli_stmt_execute($stmt);

                // Get result
                $result = mysqli_stmt_get_result($stmt);

                // Check if there are any books
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['title'] . "</td>";
                        echo "<td>" . $row['author'] . "</td>";
                        echo "<td>" . $row['publisher'] . "</td>";
                        echo "<td>" . $row['published_date'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No books found.</td></tr>";
                }

                // Close statement
                mysqli_stmt_close($stmt);
            }

            // Close connection
            mysqli_close($conn);
        ?>
    </table>
</body>
</html>

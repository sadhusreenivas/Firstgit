<?php
// Include the database connection file
require_once 'config.php';

// Fetch all posts from the database
$query = "SELECT * FROM posts ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // Loop through each row and display post information
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="post">';
        echo '<h2>' . $row['title'] . '</h2>';
        echo '<p>' . $row['content'] . '</p>';
        echo '<p>Posted by: user_id:' . $row['user_id'] . ' on ' . $row['created_at'] . '</p>';
        echo '<a href="view_post.php?id=' . $row['id'] . '">Read More</a>';
        echo '</div>';
    }
} else {
    echo 'No posts found.';
}

// Close the database connection
mysqli_close($conn);
?>







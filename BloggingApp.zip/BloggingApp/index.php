<!-- index.php -->
<?php include 'header.php'; ?>
<?php
require_once 'config.php';
session_start();
// Check if user is logged in
if (!isset($_SESSION["user_id"]) || empty($_SESSION["user_id"])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="scripts/script.js"></script>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION["username"]; ?>!</h2>
    <?php $username = $_SESSION["user_id"]; ?>
    <br>
    <div align="center">
    <h2 align="left">Posts</h2>
    <div id="posts-container">
        <!-- Display all posts from database -->
    <br>
    </div>
    <div align="center">
    <h2 align="left">New Post</h2>
    <form id="new-post-form" method="post">
        <input type="text" id="title" placeholder="Title" size="80" required>
        <textarea id="content" placeholder="Content" rows="20" cols="80" required>
        </textarea>
       <input type="number" name="user_id" value="<?php echo $username; ?>" disabled> 
        <input type="submit" name="submit" value="Add Post">
    </form>
    </div>

    <a href="logout.php">Logout</a>
    <?php echo $_SESSION["username"];?>
</body>
</html>
<?php include 'footer.php'; ?>

<!-- edit_post.php -->
<?php
require_once 'config.php';
session_start();

// Check if user is logged in, else redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
/* Get the post ID from URL parameter
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}
$postId = $_GET['id'];
*/

// Check if post request is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["post_id"])) {
    $postId = $_POST["post_id"];
    $title = $_POST["title"];
    $content = $_POST["content"];

    // Update post in the database
    $query = "UPDATE posts SET title=?, content=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $title, $content, $postId);


if (mysqli_stmt_execute($stmt)) {
    // Redirect to index.php after successful update
    header("Location: index.php");
    exit;
} else {
    echo "Failed to update post."; // Display error message if update fails
}
}
?>
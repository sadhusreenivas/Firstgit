<!-- delete_post.php -->
<?php
require_once 'config.php';
session_start();

// Check if user is logged in, else redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// Get the post ID from URL parameter
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}
    
$postId = $_GET['id'];

// Prepare and bind the parameter for the query

$query = "DELETE FROM posts WHERE id=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $postId);

if (mysqli_stmt_execute($stmt)) {
    // Redirect to index.php after successful delete
    header("Location: index.php");
    exit;
} else {
    echo "Failed to delete post."; // Display error message if delete fails
}

?>

<?php require_once "header.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Post | My Blog</title>
    <!-- Include CSS file -->
    <link rel="stylesheet" href="css/style.css">
   
</head>
<body>
    <br><br>
     <h1> Post Deleted!
     </h1>   

    <?php require_once "footer.php"; ?> <!-- Include footer -->
</body>
</html>

<?php
// Include the database connection file
require_once 'config.php';
session_start();
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $title = $_POST['title'];
    $content = $_POST['content'];
    $user_id = $_SESSION['user_id']; // assuming user is logged in

    // Perform form validation
    if (empty($title) || empty($content)) {
        echo 'Title and content are required.';
    } else {
        // Insert post data into the database
        $query = "INSERT INTO posts (title, content, user_id) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssi', $title, $content, $user_id);
        mysqli_stmt_execute($stmt);

        // Check if post was added successfully
        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo 'Post added successfully.';
        } else {
            echo 'Failed to add post.';
        }

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    }
}

// Close the database connection
mysqli_close($conn);
?>



*/

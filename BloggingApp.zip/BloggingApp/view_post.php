<?php
require_once "config_pdo.php"; // Include database configuration
session_start(); // Start session

// Check if user is logged in, else redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// Get the post ID from URL parameter
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$post_id = $_GET['id'];
//echo "$post_id";

/*
$query = "SELECT * FROM posts WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $post_id);
$post = mysqli_stmt_execute($stmt);
//$post = $post->fetch(PDO_FETCH_ASSOC);
*/

//Fetch post details from database

$stmt = $conn->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$post_id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if post exists
if (!$post) {
    header("Location: index.php");
    exit;
}
?>
<?php require_once "header.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>View Post | My Blog</title>
    <!-- Include CSS file -->
    <link rel="stylesheet" href="css/style.css">
   <script>
   // Delete Post 
   function confirmDelete() {
    var confirmDelete = confirm("Are you sure you want to delete this post?");
    if (confirmDelete) {
        return true; // Continue with the link action
    } else {
        return false; // Cancel the link action
    }
  }

  // Edit post
    function editPost(postId, title, content) {
        var newTitle = prompt("Enter new title:", title);
        var newContent = prompt("Enter new content:", content);
        if (newTitle && newContent) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "edit_post.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    fetchPosts(); // Refresh posts after editing post
                }
            };
            xhr.send("post_id=" + postId + "&title=" + newTitle + "&content=" + newContent);
        }
    }
</script>
</head>
<body>
    <br><br>
        <div class="container">
            <p><strong>Post-ID:</strong> <?php echo $post['id']; ?></p>
            <p><strong>Title: </strong><?php echo $post['title']; ?></p>
            <p><strong>Conetent: </strong><?php echo $post['content']; ?></p>
           <p><strong>User - ID:</strong> <?php echo $post['user_id']; ?></p>
            <p><strong>Created At:</strong> <?php echo $post['created_at']; ?></p>
            <p><strong>Updated At:</strong> <?php echo $post['updated_at']; ?></p>

            
            <?php if ($_SESSION['user_id'] == $post['user_id'] || $_SESSION['role'] == 'user' || $_SESSION['role'] =='admin') { ?> 
             
             <a href="#" onclick="editPost(<?php echo $post['id']; ?>, '<?php echo $post['title']; ?>', '<?php echo $post['content']; ?>')"> Edit </a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <a href="delete_post.php?id=<?php echo $post['id']; ?>" onclick="return confirmDelete();">Delete</a>

            <?php } ?>

        </div>
    <?php require_once "footer.php"; ?> <!-- Include footer -->
</body>
</html>
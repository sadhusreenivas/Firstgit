// register.js

// Function to validate registration form
function validateRegistrationForm() {
    // Get form inputs
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;

    // Perform validation
    if (username === '' || email === '' || password === '' || confirmPassword === '') {
        alert("All fields must be filled.");
        return false;
    }
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}
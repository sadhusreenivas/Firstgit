<!-- footer.php -->
    </main>
    <footer>
        <p>Anshul Sood &copy; 2023 My Blog. All rights reserved.</p>
    </footer>
</body>
</html>
<!-- config_pdo.php -->
<?php

$dsn = 'mysql:host=localhost;dbname=blog_db';
$username = 'root';
$password = '';

try {
    $conn = new PDO($dsn, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Additional configuration settings, if needed
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

?>
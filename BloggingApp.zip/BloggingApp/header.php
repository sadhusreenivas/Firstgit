<!-- header.php -->
<!DOCTYPE html>
<html>
<head>
    <title>My Blog</title>
    <!-- Include CSS and JavaScript files -->
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js"></script>
</head>
<body>
    <header>
        <h1>My Blog</h1>
        <!-- Include navigation links -->
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php">New Post</a></li>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php } else { ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php } ?>
            </ul>
        </nav>
    </header>
</body>
</html>
// script.js
document.addEventListener("DOMContentLoaded", function() {
    // Fetch and display all posts from database
    fetchPosts();

    // Add event listener to new post form
    document.getElementById("new-post-form").addEventListener("submit", function(event) {
        event.preventDefault();
        addPost();
    });

    // Fetch and display all posts from database
    function fetchPosts() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "get_posts.php", true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                document.getElementById("posts-container").innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    }

    // Add new post to the database and refresh the posts
    function addPost() {
       
        var title = document.getElementById("title").value;
        var content = document.getElementById("content").value;
        //var user_id = document.getElementsByName("user_id").value;
         
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "add_post.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                fetchPosts(); // Refresh posts after adding new post
                document.getElementById("new-post-form").reset(); // Reset form
            }
        };
        xhr.send("title=" + title + "&content=" + content);
    }

    // Edit post
    function editPost(postId, title, content) {
        var newTitle = prompt("Enter new title:", title);
        var newContent = prompt("Enter new content:", content);
        if (newTitle && newContent) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "edit_post.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    fetchPosts(); // Refresh posts after editing post
                }
            };
            xhr.send("post_id=" + postId + "&title=" + newTitle + "&content=" + newContent);
        }
    }

    // Delete post
    function deletePost(postId) {
        var confirmDelete = confirm("Are you sure you want to delete this post?");
        if (confirmDelete) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "delete_post.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    fetchPosts(); // Refresh posts after deleting post
                }
            };
            xhr.send("post_id=" + postId);
        }
    }
});


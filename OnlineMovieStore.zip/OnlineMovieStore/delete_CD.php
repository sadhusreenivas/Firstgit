<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "moviesdb");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if book id is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Prepare a delete statement
    $sql = "DELETE FROM CDs WHERE CD_ID = ?";
    
    // Prepare statement
    $stmt = mysqli_prepare($conn, $sql);
    
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        echo "CD deleted successfully.";
    } else {
        echo "Error deleting book: " . mysqli_error($conn);
    }
    
    // Close statement
    mysqli_stmt_close($stmt);
    
} else {
    echo "CD id not specified.";
}

// Close connection
mysqli_close($conn);
?>

  <br><br>
<button onclick="window.location.href='index.php'" class="button">Back to Home</button>
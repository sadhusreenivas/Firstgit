<!DOCTYPE html>
<html>
<head>
    <title>Online Movie Store</title>
    <link rel="stylesheet" href="mycss.css">
</head>
<body>
    <div align="center">
    <h1>Online Movie Store</h1>
    <h2>CD's List</h2>
    <form method="get">
        <label for="search">Search:</label>
        <input type="text" name="search">
        <button type="submit" class="button">Search</button>
    </form>
    <br>
    <table>
        <tr>
            <th>CD ID</th>
            <th>Movie Name</th>
            <th>Type</th>
            <th>Crew</th>
            <th>Year of Release</th>
            <th>No. of CDs Available</th>
        </tr>
        <?php
            // Database connection
            $conn = mysqli_connect("localhost", "root", "", "moviesdb");

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Prepare a select statement
            $sql = "SELECT * FROM CDs";

            // Check if search query is set
            if (isset($_GET['search'])) {
                $search_term = "%" . $_GET['search'] . "%";
                $sql .= " WHERE Movie_Name LIKE ?";
            }

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            if (isset($_GET['search'])) {
                mysqli_stmt_bind_param($stmt, "s", $search_term);
            }

            // Execute the prepared statement
            mysqli_stmt_execute($stmt);

            // Get result
            $result = mysqli_stmt_get_result($stmt);

            // Check if there are any books
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['CD_ID'] . "</td>";
                    echo "<td>" . $row['Movie_Name'] . "</td>";
                    echo "<td>" . $row['Type'] . "</td>";
                    echo "<td>" . $row['Crew'] . "</td>";
                    echo "<td>" . $row['Year_of_Release'] . "</td>";
                    echo "<td>" . $row['Number_of_CDs_Available'] . "</td>";
                    echo "<td>";
                    echo "<button onclick=\"window.location.href='edit_CD.php?id=" . $row['CD_ID'] . "'\" class=\"button\">Edit</button>";
                    echo "<button onclick=\"if (confirm('Are you sure you want to delete this CD?')) window.location.href='delete_CD.php?id=" . $row['CD_ID'] . "'\" class=\"button\">Delete</button>";
                    echo "</td>";
                    echo "</tr>";
                  
}
} else {
echo "<tr><td colspan='6'>No CDs found!</td></tr>";

}
// Close connection
        mysqli_close($conn);
    ?>
</table>
 <button onclick="window.location.href='add_CD.php'" class="button">Add CD</button>
 <br><br>
 <button onclick="window.location.href='index.php'" class="button">Home</button>
</div>
</body>
</html>





<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
    <style>
        form {
            width: 50%;
            margin: auto;
            border: 2px solid #008CBA;
            padding: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .button {
            background-color: #008CBA;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <?php
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "moviesdb");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Check if ID is set
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Prepare a select statement
            $sql = "SELECT * FROM CDs WHERE CD_ID = ?";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $id);

            // Execute the prepared statement
            mysqli_stmt_execute($stmt);

            // Get result
            $result = mysqli_stmt_get_result($stmt);

            // Check if book exists
            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                $name = $_POST['Movie_Name'];
                $type = $_POST['Type'];
                $crew = $_POST['Crew'];
                $year = $_POST['Year_of_Release'];
                $cds  = $_POST['Number_of_CDs_Available'];
            } else {
                echo "CD not found.";
                exit();
            }
        } else {
            echo "ID not specified.";
            exit();
        }

        // Check if form is submitted
        if (isset($_POST['submit'])) {
            $name = $_POST['Movie_Name'];
            $type = $_POST['Type'];
            $crew = $_POST['Crew'];
            $year = $_POST['Year_of_Release'];
            $cds  = $_POST['Number_of_CDs_Available'];

            // Prepare an update statement
            $sql = "UPDATE books SET Movie_Name = ?, Type = ?, Crew = ?, Year_of_Release = ?, Number_of_CDs_Available = ? WHERE CD_ID = ?";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssiii", $name, $type, $crew, $year,$cds,$id);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "CD updated successfully.";
            } else {
                echo "Error updating CD: " . mysqli_error($conn);
            }
        }
    ?>
    <h1>Edit Book</h1>
    <form method="post">
       <label for="Movie_Name">Movie Name:</label>
        <input type="text" name="Movie_Name"><br>
        <label for="Type">Type:</label>
        <input type="text" name="Type"><br>
        <label for="Crew">Crew:</label>
        <input type="text" name="Crew"><br>
        <label for="Year_of_Release">Year of Release:</label>
        <input type="number" name="Year_of_Release"><br>
        <label for="Number_of_CDs_Available">No. of CDs Avaialble:</label>
        <input type="number" name="Number_of_CDs_Available"><br><br>
        <button type="submit" name="submit">Save</button>
    </form>
     <br><br>
    <button onclick="window.location.href='index.php'" class="button">Back to Home</button>
</body>
</html>
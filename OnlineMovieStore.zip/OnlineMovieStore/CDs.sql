-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 20, 2023 at 09:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moviesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `CDs`
--

CREATE TABLE `CDs` (
  `CD_ID` int(11) NOT NULL,
  `Movie_Name` varchar(50) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Crew` varchar(100) DEFAULT NULL,
  `Year_of_Release` int(11) DEFAULT NULL,
  `Number_of_CDs_Available` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `CDs`
--

INSERT INTO `CDs` (`CD_ID`, `Movie_Name`, `Type`, `Crew`, `Year_of_Release`, `Number_of_CDs_Available`) VALUES
(1, 'The Shawshank Redemption', 'Drama', 'Frank Darabont', 1994, 10),
(2, 'The Godfather', 'Crime', 'Francis Ford Coppola', 1972, 8),
(3, 'The Dark Knight', 'Action', 'Christopher Nolan', 2008, 12),
(5, 'Forrest Gump', 'Drama', 'Robert Zemeckis', 1994, 5),
(6, 'The Lord of the Rings: The Return of the King', 'Fantasy', 'Peter Jackson', 2003, 9),
(8, 'Avatar2', 'Fiction', 'James Cameroon', 2022, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CDs`
--
ALTER TABLE `CDs`
  ADD PRIMARY KEY (`CD_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CDs`
--
ALTER TABLE `CDs`
  MODIFY `CD_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

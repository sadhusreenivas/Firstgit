<!DOCTYPE html>
<html>
<head>
    <title>Add CD</title>
     <link rel="stylesheet" href="mycss.css">
      <style>
        form {
            width: 50%;
            margin: auto;
            border: 2px solid #008CBA;
            padding: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .button {
            background-color: #008CBA;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <?php
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "moviesdb");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Check if form is submitted
        if (isset($_POST['submit'])) {
            $name = $_POST['Movie_Name'];
            $type = $_POST['Type'];
            $crew = $_POST['Crew'];
            $year = $_POST['Year_of_Release'];
            $cds  = $_POST['Number_of_CDs_Available'];

            // Prepare an insert statement
            $sql = "INSERT INTO CDs (Movie_Name,Type,Crew,Year_of_Release,Number_of_CDs_Available) VALUES (?, ?, ?, ?,?)";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "sssii", $name, $type, $crew, $year, $cds);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "CD added successfully.";
            } else {
                echo "Error adding CD: " . mysqli_error($conn);
            }
        }
    ?>
    <div align="center">
    <h1>Add CD</h1>
    <form method="post">
        <label for="Movie_Name">Movie Name:</label>
        <input type="text" name="Movie_Name"><br>
        <label for="Type">Type:</label>
        <input type="text" name="Type"><br>
        <label for="Crew">Crew:</label>
        <input type="text" name="Crew"><br>
        <label for="Year_of_Release">Year of Release:</label>
        <input type="number" name="Year_of_Release"><br>
        <label for="Number_of_CDs_Available">No. of CDs Avaialble:</label>
        <input type="number" name="Number_of_CDs_Available"><br>

        <button type="submit" name="submit">Add CD</button>
    </form>
    <br><br>
    <button onclick="window.location.href='index.php'" class="button">Back to Home</button>
</div>
</body>
</html>

